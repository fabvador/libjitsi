package net.sf.fmj.media.content.audio.x_wav;

import net.sf.fmj.media.handler.JavaSoundHandler;

/**
 * Experimental handler for WAV files.
 * 
 * @author Ken Larson
 *
 */
public class Handler extends JavaSoundHandler
{
}