package net.sf.jdshow;

/**
 *
 * @author Ken Larson
 *
 */
public class IDispatch extends IUnknown
{
    public IDispatch(long ptr)
    {
        super(ptr);

    }

}
