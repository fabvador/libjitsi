package net.sf.fmj.ui.wizards;

/**
 *
 * @author Ken Larson
 *
 */
public class TranscodeWizardResult extends ProcessorWizardResult
{
}
