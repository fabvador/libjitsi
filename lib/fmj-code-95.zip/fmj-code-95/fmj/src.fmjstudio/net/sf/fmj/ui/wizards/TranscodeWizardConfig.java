package net.sf.fmj.ui.wizards;

/**
 *
 * @author Ken Larson
 *
 */
public class TranscodeWizardConfig extends ProcessorWizardConfig
{
}
