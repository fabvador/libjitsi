package net.sf.fmj.ui.wizards;

import javax.media.protocol.*;

/**
 *
 * @author Ken Larson
 *
 */
public class ProcessorWizardConfig
{
    public String url;
    public ContentDescriptor contentDescriptor;
    public TrackConfig[] trackConfigs;
    // public ParsedRTPUrl destUrl;
    public String destUrl;
}
