package net.sf.fmj.ui.registry;

/**
 *
 * @author Ken Larson
 *
 */
public interface DetailsListener
{
    public void onDetails(String text);
}
