package ejmf.toolkit.util;

public interface Sortable {
    public boolean lessThan(Sortable value);
}
